
<?php
echo "Folder public berhasil dibaca Apache!";
