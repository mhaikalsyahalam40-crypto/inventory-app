
<?php
require_once __DIR__ . '/config/database.php';

$username = 'admin';
$password = 'admin123';
$fullName = 'Administrator';
$role = 'admin';

// Cek apakah username sudah ada
$stmt = $pdo->prepare(
    'SELECT id FROM users WHERE username = ? LIMIT 1'
);
$stmt->execute([$username]);

if ($stmt->fetch()) {
    exit('Akun admin sudah ada. Silakan login.');
}

// Simpan password dalam bentuk hash
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $pdo->prepare(
    'INSERT INTO users (username, password_hash, full_name, role)
     VALUES (?, ?, ?, ?)'
);

$stmt->execute([
    $username,
    $passwordHash,
    $fullName,
    $role
]);

echo 'Akun admin berhasil dibuat!';
