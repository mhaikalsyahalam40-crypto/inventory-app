
<?php
echo "Folder utama inventory-app berhasil dibaca!";
